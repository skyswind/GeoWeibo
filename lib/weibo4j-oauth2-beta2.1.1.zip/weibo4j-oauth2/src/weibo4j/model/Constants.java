package weibo4j.model;

public class Constants {
    public static final String X_AUTH_MODE = "client_auth";
    public static final String UPLOAD_MODE = "pic";
}
